# Roobet Crash Queries

Takes Hash of Game to get information about game and previous crash games

## Installation

`pip install roobet`

## How to use it?

```python
from roobet import *
Client = crash()
Client.get_multiplier('c1f9e32a46429842615c9b854147a4818811ee4506b43ecb96c0615be8560c93')
```

## License

© 2021 Drew Nicolette

This repsitory is licensed under the MIT license. See LICENSE for details.
